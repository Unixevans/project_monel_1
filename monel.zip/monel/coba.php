<?php
$conn = mysqli_connect("localhost", "root", "", "simonel");
// ----
$time1 = "18:27:40";
$time2 = "18:27:58";
$time3 = "18:28:15";
$time4 = "18:28:51";

// ---
$v = mysqli_query($conn, "SELECT voltageA FROM pzem_data");
$volt = mysqli_query($conn, "SELECT voltageA FROM pzem_data WHERE TIME(created_at) = '$time1' AND TIME(created_at) = '$time2' AND TIME(created_at) = '$time3'");





?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php while ($row = mysqli_fetch_array($volt)) {
        echo $row['voltageA'];
    }
    ?>

</body>


</html>