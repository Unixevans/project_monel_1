<?php
// if ($_SERVER['REQUEST_METHOD'] === 'POST') {
//     $tanggal = $_POST['tanggal'];

//     session_start();
//     $_SESSION['tanggal'] = $tanggal;
// }

// if (isset($_SESSION['tanggal'])) {
//     $tgl = $_SESSION['tanggal'];
//     echo $tgl;
// }

$tgl = $_POST['tanggal'];
echo $tgl;
?>
<!-- f -->