<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    .wrappeck {
        max-height: 120px;
        max-width: 500px;
        border: 1px solid black;
        display: flex;
        overflow-y: hidden;
        overflow-x: auto;
    }

    /* .wrappeck::-webkit-scrollbar {
        width: 0;
    } */

    .wrappeck .item {
        min-width: 110px;
        height: 110px;
        line-height: 110px;
        text-align: center;
        border: 1px solid lightgray;
    }
</style>

<body>
    <div class="wrappeck">
        <div class="item">box-1</div>
        <div class="item">box-2</div>
        <div class="item">box-3</div>
        <div class="item">box-4</div>
        <div class="item">box-5</div>
        <div class="item">box-6</div>
        <div class="item">box-7</div>
    </div>
</body>

</html>