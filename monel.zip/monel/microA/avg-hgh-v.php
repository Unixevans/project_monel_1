<?php
// Connection
$conn = mysqli_connect("localhost", "root", "", "simonel");

// Higher Voltage
$result1 = mysqli_query($conn, "SELECT MAX(voltageA) as max_teg FROM pzem_data");
$higher = mysqli_fetch_array($result1);
$max_teg = $higher['max_teg'];

// Average Voltage
$result2 = mysqli_query($conn, "SELECT AVG(voltageA) as avg_teg FROM pzem_data");
$avg = mysqli_fetch_array($result2);
$avg_teg = $avg["avg_teg"];
$avg_teg_formatted = number_format($avg_teg, 1);

?>
<!-- jjjj -->