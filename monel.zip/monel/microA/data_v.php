<?php
$connect = mysqli_connect("localhost", "root", "", "simonel");

// Syntax Query for Date Sumbu X
$tanggal = mysqli_query($connect, "SELECT created_at FROM pzem_data ORDER BY ID ASC");
// Syntax Query for Data Sumbu Y

// if (isset($_POST['date_picker'])) {
//     $nilai_data = $_POST['date_picker'];
//     echo $nilai_data;
// }

$voltageA = mysqli_query($connect, "SELECT voltageA FROM pzem_data ORDER BY ID ASC");


?>


<!-- View for The Graphic -->
<div style="width: 100%;">
    <div style="text-align: center;height: 30px; align-items:center; font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;">
        STATISTIK TEGANGAN MICROINVENTER A
    </div>
    <div class="panel-body">
        <!-- Prepared canvas for Graphic -->
        <canvas id="myChart-v"></canvas>

        <script>
            var canvas_v = document.getElementById('myChart-v');
            // Prepared for the graphic
            var data_v = {
                labels: [
                    <?php
                    while ($data_tanggal = mysqli_fetch_array($tanggal)) {
                        $date = date('Y-m-d', strtotime($data_tanggal['created_at']));
                        $time = date('H:i', strtotime($data_tanggal['created_at']));
                        echo '"' . $time . '",';
                    }
                    ?>
                ],
                datasets: [{
                    label: "Tegangan",
                    fill: true,
                    backgroundColor: "rgba(253, 233, 5, .7)",
                    borderColor: "rgba(253, 233, 5, 2)",
                    data: [
                        <?php
                        while ($data_voltageA = mysqli_fetch_array($voltageA)) {
                            echo $data_voltageA['voltageA'] . ',';
                        }
                        ?>
                    ]
                }]
            };

            // option for the graphic
            var option_v = {
                showLines: true,
                animation: {
                    duration: 0
                }
            };

            // print the graphic
            var myLineChart = Chart.Line(canvas_v, {
                data: data_v,
                options: option_v
            });
        </script>


    </div>


</div>