<?php
// koneksi database
$conn = mysqli_connect("localhost", "root", "", "monitoring_panel");

// read the higher id from tb_sensor
$sql_ID = mysqli_query($conn, "SELECT MAX(ID) FROM tb_sensor");
// catch the data
$data_ID = mysqli_fetch_array($sql_ID);
// take the bigger id/ latest id
$ID_akhir = $data_ID['MAX(ID)'];
$ID_awal = $ID_akhir - 9;


// read the data from table tb_sensor
// read infromation latest date to all data
$tanggal = mysqli_query($conn, "SELECT created_at FROM tb_sensor WHERE ID>='$ID_awal' AND ID<='$ID_akhir' ORDER BY ID ASC");
// tegangan
$teganganA = mysqli_query($conn, "SELECT teganganA FROM tb_sensor WHERE ID>='$ID_awal' AND ID<='$ID_akhir' ORDER BY ID ASC");
$teganganB = mysqli_query($conn, "SELECT teganganB FROM tb_sensor WHERE ID>='$ID_awal' AND ID<='$ID_akhir' ORDER BY ID ASC");
// arus
$currentA = mysqli_query($conn, "SELECT currentA FROM tb_sensor WHERE ID>='$ID_awal' AND ID<='$ID_akhir' ORDER BY ID ASC");
$currentB = mysqli_query($conn, "SELECT currentB FROM tb_sensor WHERE ID>='$ID_awal' AND ID<='$ID_akhir' ORDER BY ID ASC");
// daya semu
$dayasemuA = mysqli_query($conn, "SELECT dayasemuA FROM tb_sensor WHERE ID>='$ID_awal' AND ID<='$ID_akhir' ORDER BY ID ASC");
$dayasemuB = mysqli_query($conn, "SELECT dayasemuB FROM tb_sensor WHERE ID>='$ID_awal' AND ID<='$ID_akhir' ORDER BY ID ASC");
// daya nyata
$dayanyataA = mysqli_query($conn, "SELECT dayanyataA FROM tb_sensor WHERE ID>='$ID_awal' AND ID<='$ID_akhir' ORDER BY ID ASC");
$dayanyataB = mysqli_query($conn, "SELECT dayanyataB FROM tb_sensor WHERE ID>='$ID_awal' AND ID<='$ID_akhir' ORDER BY ID ASC");
// daya reaktif
$dayareaktifA = mysqli_query($conn, "SELECT dayareaktifA FROM tb_sensor WHERE ID>='$ID_awal' AND ID<='$ID_akhir' ORDER BY ID ASC");
$dayareaktifB = mysqli_query($conn, "SELECT dayareaktifB FROM tb_sensor WHERE ID>='$ID_awal' AND ID<='$ID_akhir' ORDER BY ID ASC");


?>


<!-- view graphic -->
<div class="panel panel-primary" style="margin-bottom: 50px;">
    <div class="panel-heading">
        TEGANGAN
    </div>


    <div class="panel-body" style="margin-bottom: 50px;">
        <!-- prepare canvas for graphic -->
        <canvas id="myChart-v"></canvas>

        <!-- draw the graphic -->
        <script>
            // read the id canvas
            var canvas_v = document.getElementById('myChart-v');

            // place data date and suhu for graphic
            var data_v = {
                labels: [
                    <?php
                    while ($data_tanggal = mysqli_fetch_array($tanggal)) {
                        echo '"' . $data_tanggal['created_at'] . '",';
                    }
                    ?>
                ],
                datasets: [{
                        label: "Micro Inventer A",
                        fill: true,
                        backgroundColor: "rgba(158, 140, 255, 0.38)",
                        borderColor: "rgba(158, 140, 255, 1)",
                        lineTension: 0.5,
                        pointRadius: 5,
                        data: [
                            <?php
                            while ($data_teganganA = mysqli_fetch_array($teganganA)) {
                                echo $data_teganganA['teganganA'] . ',';
                            }
                            ?>
                        ]
                    },
                    {
                        label: "Micro Inventer B",
                        fill: true,
                        backgroundColor: "rgba(158, 140, 255, 0.38)",
                        borderColor: "rgba(158, 140, 255, 1)",
                        lineTension: 0.5,
                        pointRadius: 5,
                        data: [
                            <?php
                            while ($data_teganganB = mysqli_fetch_array($teganganB)) {
                                echo $data_teganganB['teganganB'] . ',';
                            }
                            ?>
                        ]
                    }

                ]
            };

            // option for graphic
            var option_v = {
                showLines: true,
                animation: {
                    duration: 0
                }
            };
            // print the graphic to canvas
            var myLineChart = Chart.Line(canvas_v, {
                data: data_v,
                options: option_v
            });
        </script>
    </div>
</div>